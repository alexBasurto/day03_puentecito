# Hacer mucha fuerza cuando defecamos podría llegar a matarnos #

Esta es una de esas noticias que no podemos dejar pasar por alto. Y si, pujar, hacer mucha fuerza cuando defecamos podría llegar a matarnos…

Científicos de Estados Unidos, han llegado a esta “dura” conclusión después de estudiar a pacientes estreñidos con problemas cardiovasculares.

Si bien no es común que suceda, existe una probabilidad menos al 1% de que personas afectadas cardiovasculares puedan morir mientras defecan, concluye el estudio.

Pero para formar parte de esta estadística (de mierda) debemos cumplir con dos circunstancias particulares; primero tener algún tipo de patología cardiovascular, como ser insuficiencia cardiaca. Segundo tener problemas de estreñimientos, es decir, evacuar de manera muy dura o seca.

El estreñimiento, obliga a las personas a realizar un mayor esfuerzo, aumentando el flujo de sangre en el abdomen, lo que impide que la sangre llegue de manera normal al corazón y al cerebro. Para las personas en grupo de riesgo dicho esfuerzo puede resultar mortal.

Es por ello que si te encuentras dentro del grupo de riesgo, te recomendamos el uso de un laxante, que te ayudara con un tránsito fluido en estas ocasiones.Si te encuentras fuera  del grupo de riesgo, no te preocupes,  solo te abatirá el sudor, pero no carrera riesgo tu permanencia en este mundo…
