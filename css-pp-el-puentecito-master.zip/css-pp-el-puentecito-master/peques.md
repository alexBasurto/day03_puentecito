# Un grupo de niños brasileños apedrea a Papá Noel tras quedarse sin caramelos #

## "Comenzaron a correr detrás de nosotros insultándonos y tirándonos piedras y dulces" ##

Un grupo de niños decidió apedrear a Papá Noel tras quedarse éste sin caramelos que repartir durante un desfile navideño en el municipio de Itatiba, en el estado brasileño de Sao Paulo, informaron este miércoles medios locales.

El Papá Noel recorría las calles de la localidad, a la altura del barrio de Porto Seguro, y en un momento dado se le acabaron los caramelos, lo que indignó a siete niños, de entre 9 y 12 años, que no dudaron en reaccionar lanzándole piedras.

"Comenzaron a correr detrás de nosotros insultándonos y tirándonos piedras y dulces", relató al portal UOL uno de los ayudantes que acompañaba a Papá Noel. Ninguno de los voluntarios que participaba en el desfile, incluido Papá Noel, resultó herido. De acuerdo con el citado medio, el incidente ya se había repetido otros años en el mismo barrio.

El tradicional desfile lo protagoniza el conocido como Papá Noel Luizao, dueño de una funeraria que desde hace años, por estas fechas, reparte caramelos entre los más pequeños del municipio paulista.

El Papá Noel en cuestión no quiso hablar con los medios de comunicación pero en su perfil de redes sociales se lamentó de lo sucedido y afirmó que hasta el día 25 va a "intentar pasar por la avenida principal" para seguir repartiendo caramelos.

"Desgraciadamente en aquel momento los caramelos se acabaron", manifestó, al tiempo que pidió la colaboración de los vecinos para que ayuden a recolectar dulces y los donen para repartirlos. "Vamos con fe a continuar con esta tradición que alegra tanto a todos en Itatiba", añadió.

Por su parte, la Alcaldía de Itatiba dijo en una nota no tener conocimiento de la agresión a Papá Noel Luizao y su equipo, y se limitó a decir que la localidad cuenta por estas fechas con Papás Noel voluntarios que "recorren los barrios de forma independiente, sin vínculo con la Administración".
